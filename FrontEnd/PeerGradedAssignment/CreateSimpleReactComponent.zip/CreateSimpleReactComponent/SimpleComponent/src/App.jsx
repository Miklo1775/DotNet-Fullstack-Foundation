import "./App.css";
import SimpleComponent from "./components/SimpleComponent";

function App() {
  return <SimpleComponent />;
}

export default App;
